#include "GameManager.h"

int main() {
	GameManager mgr ;
	mgr.Run() ;
}
