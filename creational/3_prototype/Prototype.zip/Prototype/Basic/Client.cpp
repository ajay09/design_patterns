#include "Client.h"

#include "Prototype.h"
void Client::Operation() {
	auto p = prototype->Clone() ;
}
