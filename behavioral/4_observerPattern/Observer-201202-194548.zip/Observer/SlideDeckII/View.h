#pragma once
class View
{
public:
	virtual void Display(size_t index) = 0 ;
	virtual ~View()=default ;
};

