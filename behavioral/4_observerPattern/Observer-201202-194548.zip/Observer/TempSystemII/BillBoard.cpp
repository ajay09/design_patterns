#include "BillBoard.h"

#include <iostream>

void BillBoard::Notify(float value) {
	std::cout << "Billboard [" << value << "]\n" ;
}
