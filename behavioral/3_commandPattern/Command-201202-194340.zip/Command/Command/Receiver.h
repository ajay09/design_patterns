#pragma once
#include "Command.h"

class Receiver/* : public Command*/
{
public:
	void Action() ;
	void Execute() ;
};

