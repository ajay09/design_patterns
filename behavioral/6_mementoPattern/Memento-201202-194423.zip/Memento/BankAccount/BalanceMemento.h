#pragma once
class BalanceMemento
{
	int m_Balance{} ;

public:
	BalanceMemento(int mBalance);
	int GetBalance()const ;
};

