#include "ConcreteClass.h"

int main() {
	ConcreteClass cc{} ;
	cc.TemplateMethod() ;
}
