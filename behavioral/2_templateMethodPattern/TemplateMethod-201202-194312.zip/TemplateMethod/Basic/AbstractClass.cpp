#include "AbstractClass.h"

void AbstractClass::TemplateMethod() {
	PrimitiveOperation1() ;
	PrimitiveOperation2() ;
}
