#pragma once
#include "Strategy.h"
class ConcreteStrategyA :
    public Strategy
{

public:
	void AlgorithInterface() override;
};

