#include "ConcreteStrategyA.h"

#include <iostream>

void ConcreteStrategyA::AlgorithInterface() {
	std::cout << "Using ConcreteStrategyA\n" ;
}
