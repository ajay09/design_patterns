#include "ConcreteStrategyB.h"

#include <iostream>

void ConcreteStrategyB::AlgorithInterface() {
	std::cout << "Using ConcreteStrategyB\n" ;
}
