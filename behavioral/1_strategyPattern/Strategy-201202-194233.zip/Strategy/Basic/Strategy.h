#pragma once
class Strategy
{
public:
	virtual void AlgorithInterface() = 0 ;
	virtual ~Strategy()=default ;
};

