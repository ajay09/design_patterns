#pragma once
#include "Strategy.h"
class ConcreteStrategyB :
    public Strategy
{

public:
	void AlgorithInterface() override;
};

